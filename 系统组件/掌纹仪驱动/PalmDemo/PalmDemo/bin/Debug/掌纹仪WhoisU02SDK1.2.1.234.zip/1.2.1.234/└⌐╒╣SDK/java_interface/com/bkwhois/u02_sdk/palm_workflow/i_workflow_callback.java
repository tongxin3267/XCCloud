/**
 *
 */
package com.bkwhois.u02_sdk.palm_workflow;

import com.bkwhois.u02_sdk.palm_algorithm.data_struct.*;

/**
 * @author 陶海军
 *
 */
/// 掌纹注册/识别流程的回调接口
public interface i_workflow_callback {
    /// workflow可能产生的事件，要参考C++代码中workflow_actions枚举的定义
    /// 用户识别成功
    public static final int ACTION_USER_LOGIN = 0;
    /// 组认证成功
    public static final int ACTION_GROUP_LOGIN = 1;
    /// 识别超时，当前为10秒
    public static final int ACTION_LOGIN_TIMEOUT = 2;
    /// 注册进行中，两个参数分别为wparam=（阶段总数，当前阶段），lparam=当前所处步骤（3阶段注册为0～7）
    public static final int ACTION_ENROLL_STAGE = 3;
    /// 注册过程中候选图像数量通知，lparam 低16位为需要的图像总数, 高16位为当前候选图像数量
    public static final int ACTION_ENROLL_CANDIDATE_COUNT = 4;
    /// 注册成功
    public static final int ACTION_ENROLL_SUC = 5;
    /// 注册失败
    public static final int ACTION_ENROLL_FAIL = 6;

    /// 在workflow启动前的初始化调用
    /// @param image_cx 图像宽度
    /// @param image_cy 图像高度
    /// @return 初始化成功 or 失败
    public abstract boolean init(final int image_cx, final int image_cy);

    /// 新图像到来，通知客户程序更新
    /// @param display_info 图像信息，当注册流程收不到图像时，会发送0给本接口
    /// @param fea_str, 特征字符串，当为特征采集模式时，是一帧图像的特征，当为注册模式时，此参数无意义
    /// @param md5, 特征字符串的md5值
    /// @note 当前图像是同步传输，因此本函数不返回时，注册流程不会继续，请保证本函数尽快返回，以防影响注册流程阻塞。
    public abstract void attach(frame_info display_info, String fea_str, String md5);

    /// 给客户端发送通知，例如识别、注册等动作，具体动作依据注册流程决定 @see workflow_actions
    /// @param Msg 通知的类型
    /// @param wParam 通知参数1
    /// @param lparam 通知参数2
    /// @param tmpl_str 特征模板串，当为注册模式时，为手掌特征，当为特征采集模式时，此参数无意义
    /// @param md5, 特征模板的md5值
    /// @return 通知的处理结果
    public abstract int notify(final int Action, final int wParam, final int lParam, String tmpl_str, String md5);
}
