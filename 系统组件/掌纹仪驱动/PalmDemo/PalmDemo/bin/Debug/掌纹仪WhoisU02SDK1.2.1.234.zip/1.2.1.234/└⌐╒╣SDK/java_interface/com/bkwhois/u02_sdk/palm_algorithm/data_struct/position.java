/**
 *
 */
package com.bkwhois.u02_sdk.palm_algorithm.data_struct;

/**
 * @author 陶海军
 *
 */
public class position {

    public card_point c_pt;
    public card_point p_pt;

    public void set(final position new_pos) {
        c_pt.set_x(new_pos.c_pt.get_x());
        c_pt.set_y(new_pos.c_pt.get_y());

        p_pt.set_x(new_pos.p_pt.get_x());
        p_pt.set_y(new_pos.p_pt.get_y());
    }
}
