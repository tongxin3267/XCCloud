﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Collections;
namespace WhoIS
{
    public partial class Form1 : Form
    {
        string Feature_str = "";
        
        string Temp_str = "";
        [DllImport("web_feature_match.dll")]
        public static extern int create_partition(int id, int multi_thread);

	/// 1vN模式删除分区，如果要删除的分区是当前使用分区，那么当前分区被重置为缺省的0分区
	/// @id 要创建的分区标记
	/// @return 删除成功返回非0，失败返回0.
         [DllImport ("web_feature_match.dll")]
        public static extern int delete_partition(int id);

	/// 设定比对策略
	/// @param partition_id 要设定的分区id
	/// @param policy 比对策略, 参见@see palm_detect_intensity
	/// @return 0代表失败，非0代表成功
       [DllImport("web_feature_match.dll")]
        public static extern int set_match_policy(int partition_id, int policy);

	/// 1v1特征比对函数
	/// @param partition_id 要设定的分区id
	/// @param feature_str 图像采集析取到的特征串，BASE64编码，RC4加密
	/// @param md5 @see feature_str 的md5值
	/// @param user_template_str 用户预注册特征，BASE64编码，RC4加密
	/// @return !=0为有效的比对，0为无效比对
        [DllImport("web_feature_match.dll")]
        public static extern int match_1v1(int partition_id, string feature_str, string md5, string user_template_str);

	/// 1vN特征比对模式用户注册特征的插入/修改函数
	/// @param partition_id 要设定的分区id
	/// @param user_name 用户名
	/// @param user_template_str 用户特征串
	/// @return 特征插入成功与否
        [DllImport("web_feature_match.dll")]
        public static extern int push_template(string user_name, string user_template_str);

	/// 清空动态库中的特征库
	/// @param partition_id 要设定的分区id
        [DllImport("web_feature_match.dll")]
        public static extern void clear_templates(int partition_id);

	/// 从动态库中删除指定用户特征
	/// @param partition_id 要设定的分区id
	/// @param user_name 要删除的用户名
	/// @return 删除成功与否
        [DllImport("web_feature_match.dll")]
        public static extern void delete_template(string user_name);

    /// partition_id 要操作的分区号
    /// user_name 要添加到分区中的用户名
    ///	return 非0成功，0失败
        [DllImport("web_feature_match.dll")]
        public static extern int assign_user_to_partition(int partition_id, string user_name);

	/// 1vN比对函数
	/// @param partition_id 要设定的分区id
	/// @param feature_str 图像采集析取到的特征串，BASE64编码，RC4加密
	/// @param md5 @see feature_str 的md5值
	/// @param user_template_str 用户预注册特征，BASE64编码，RC4加密
	/// @return 0为失败，非0为成功。当所有要比对的特征都已传完，调用@see get_identify_user_name获取识别结果
        [DllImport("web_feature_match.dll")]
        public static extern int match_1vN(int partition_id, string feature_str, string md5);

	/// 1vN比对模式的识别结果获取
	/// @param partition_id 要设定的分区id
	/// @return 返回识别的用户名，如果为空代表识别失败
        [DllImport("web_feature_match.dll")]
        public static extern IntPtr match_1vN_get_identify_user_name(int partition_id);

	/// 1vN模式清理识别结果，当要进行新一轮识别时调用
	/// @param partition_id 要设定的分区id
        [DllImport("web_feature_match.dll")]
        public static extern void match_1vN_reset_identify_process(int partition_id);
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void axwhois_enroll_ocx1_EnrollFinish(object sender, Axwhois_enroll_ocxLib._Dwhois_enroll_ocxEvents_EnrollFinishEvent e)
        {
            Feature_str = e.feature_str;
            axwhois_feature_extract1.start("", "");
            //axwhois_enroll_ocx1.stop();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            axwhois_feature_extract1.stop();
            axwhois_enroll_ocx1.start("", "");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            axwhois_feature_extract1.start("", "");
        }

        private void axwhois_feature_extract1_FeatureGot(object sender, Axwhois_feature_extractLib._Dwhois_feature_extractEvents_FeatureGotEvent e)
        {
            Temp_str = e.feature_str;
            create_partition(0, 0);
            push_template("aaa", Feature_str);
            assign_user_to_partition(0, "aaa");
            if (0 != match_1vN(0, Temp_str, ""))
            {
                IntPtr IPtr = match_1vN_get_identify_user_name(0);

                if (Marshal.PtrToStringAnsi(IPtr) != "")
                    MessageBox.Show(Marshal.PtrToStringAnsi(IPtr));
                match_1vN_reset_identify_process(0);
            }
            //axwhois_feature_extract1.stop();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            create_partition(0, 0);
            push_template("aaa", Feature_str);

            IntPtr IPtr;
            if (0 != match_1vN(0, Temp_str, ""))
            {
                IPtr = match_1vN_get_identify_user_name(0);
                Text = Marshal.PtrToStringAnsi(IPtr);
            }
        }
    }
}
