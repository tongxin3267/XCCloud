// EnrollDlg.cpp : implementation file
//

#include "stdafx.h"
#include "whois_sdk_demo.h"
#include "EnrollDlg.h"
#include "UserNameDlg.h"
#include "simple_user_manager.h"

// CEnrollDlg dialog

#define AUTO_START_TIMER 101
#define AUTO_CLOSE_TIMER 102

extern int get_elapse_time();

IMPLEMENT_DYNAMIC(CEnrollDlg, CDialog)

CEnrollDlg::CEnrollDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEnrollDlg::IDD, pParent)
	, _small_templ(FALSE)
	, _bone_stage(FALSE)
	, _language_id(0)
{
}

CEnrollDlg::~CEnrollDlg()
{
}

void CEnrollDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_WHOIS_ENROLL_OCXCTRL1, m_enroll_ctrl);
	DDX_Check(pDX, IDC_SMALL_TEMPL_CHECK, _small_templ);
	DDX_Check(pDX, IDC_ONE_STAGE_CHECK, _bone_stage);
	DDX_CBIndex(pDX, IDC_LANGUAGE_COMBO, _language_id);
}


BEGIN_MESSAGE_MAP(CEnrollDlg, CDialog)
	ON_BN_CLICKED(IDB_START, &CEnrollDlg::OnBnClickedStart)
	ON_WM_CLOSE()
	ON_WM_CLOSE()
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CEnrollDlg message handlers

BOOL CEnrollDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#ifdef ROBUST_TEST
	SetTimer(AUTO_START_TIMER, 1000, 0);
#endif

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
BEGIN_EVENTSINK_MAP(CEnrollDlg, CDialog)
	ON_EVENT(CEnrollDlg, IDC_WHOIS_ENROLL_OCXCTRL1, 1, CEnrollDlg::EnrollFinish, VTS_BSTR VTS_BSTR)
	ON_EVENT(CEnrollDlg, IDC_WHOIS_ENROLL_OCXCTRL1, 2, CEnrollDlg::EnrollFail, VTS_NONE)
END_EVENTSINK_MAP()

void CEnrollDlg::EnrollFinish(LPCTSTR feature_str, LPCTSTR md5)
{
	CUserNameDlg dlg;
	dlg.DoModal();

	m_user_name = dlg.m_username;
	_feature_str = ws2s(feature_str);
	_md5 = ws2s(md5);

//	m_enroll_ctrl.save_image(L"D:\\", L"ABC");

	OnOK();
}

void CEnrollDlg::EnrollFail()
{
	AfxMessageBox(_T("ע��ʧ��!"));

	OnCancel();
}

void CEnrollDlg::OnBnClickedStart()
{
	UpdateData();

	string empty_id;

	m_enroll_ctrl.set_language(_language_id);
	m_enroll_ctrl.set_enroll_type(_small_templ?1:0);

	if(_bone_stage)
		m_enroll_ctrl.set_one_stage_enroll();

	if(!m_enroll_ctrl.start(s2ws(empty_id).c_str(), s2ws(".").c_str())) {
		AfxMessageBox(_T("�޷������ɼ��ؼ��������豸�Ƿ����Ӻò���ȷ������"));
	}

	GetDlgItem(IDB_START)->EnableWindow(FALSE);

#ifdef ROBUST_TEST
	SetTimer(AUTO_CLOSE_TIMER, get_elapse_time(), 0);
#endif
}

void CEnrollDlg::OnClose()
{
	m_enroll_ctrl.stop();

	CDialog::OnClose();
}


void CEnrollDlg::OnTimer(UINT_PTR nIDEvent)
{
	KillTimer(nIDEvent);

	if(nIDEvent == AUTO_START_TIMER) {
		OnBnClickedStart();
	}
	else if(nIDEvent == AUTO_CLOSE_TIMER) {
		OnCancel();
	}

	CDialog::OnTimer(nIDEvent);
}
