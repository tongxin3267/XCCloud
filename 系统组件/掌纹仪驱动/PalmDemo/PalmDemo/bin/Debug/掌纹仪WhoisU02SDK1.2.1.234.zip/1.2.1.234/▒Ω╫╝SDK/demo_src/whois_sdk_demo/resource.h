//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by whois_sdk_demo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_WHOIS_SDK_DEMO_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDD_ENROLL_DIALOG               130
#define IDD_NAME_INPUT_DIALOG           132
#define IDC_WHOIS_FEATURE_EXCTRL1       1000
#define IDC_ENROLL_BUTTON               1001
#define IDC_WHOIS_ENROLL_OCXCTRL1       1002
#define IDC_USER_NAME_EDIT              1003
#define IDC_USER_LIST                   1004
#define IDC_DELETE_USER_BUTTON          1005
#define IDC_SMALL_TEMPL_CHECK           1006
#define IDC_ONE_STAGE_CHECK             1007
#define IDC_LANGUAGE_COMBO              1008
#define IDB_START                       1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
