#pragma once
#include "afxwin.h"


// CUserNameDlg dialog

class CUserNameDlg : public CDialog
{
	DECLARE_DYNAMIC(CUserNameDlg)

public:
	CUserNameDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CUserNameDlg();

// Dialog Data
	enum { IDD = IDD_NAME_INPUT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	CString m_username;
	virtual BOOL OnInitDialog();
protected:
	virtual void OnCancel();
};
