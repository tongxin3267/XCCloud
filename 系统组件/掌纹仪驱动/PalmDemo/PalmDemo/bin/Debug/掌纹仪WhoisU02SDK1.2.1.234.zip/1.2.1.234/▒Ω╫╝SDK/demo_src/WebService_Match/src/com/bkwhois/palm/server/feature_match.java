package com.bkwhois.palm.server;

public class feature_match {
	public native boolean create_partition(final int partition_id, final boolean bmulti_thread);
	public native boolean delete_partition(final int partition_id);
	public native void clear_partitions();

	public native boolean set_match_policy(final int partition_id, final int match_policy);

	public native boolean push_template(final String user_name, final String user_template_str);
	public native void delete_template(final String user_name);
	public native void clear_templates();
	public native boolean assign_user_to_partition(final int partition_id, final String user_name);
	public native void remove_user_from_partition(final int partition_id, final String user_name);
	
	public native boolean match_1v1(final int partition_id, final String feature_str, final String feature_md5, final String enrolled_template);
	public native boolean match_1v1_in_memory(final int partition_id, final String feature_str, final String feature_md5, final String usr_name);

	public native boolean match_1vN(final int partition_id, final String feature_str, final String feature_md5);
	public native String  match_1vN_get_identify_user_name(final int partition_id);
	public native void	  match_1vN_reset_identify_process(final int partition_id);
	
	static{
		System.loadLibrary("web_feature_match");
	}
}
