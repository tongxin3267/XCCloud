/**
 * 
 */
package com.bkwhois.u02_sdk.palm_algorithm.data_struct;

/**
 * @author 陶海军
 *
 */
public class frame_info extends image_pair {
    public frame_info(final int width, final int height, byte[] li_image, byte[] ir_image, final crop_results crop_rslt) {
        super(width, height, li_image, ir_image);

        this._crop_rslt = crop_rslt;
    }

    /// 图像切割结果
    public crop_results _crop_rslt;
}