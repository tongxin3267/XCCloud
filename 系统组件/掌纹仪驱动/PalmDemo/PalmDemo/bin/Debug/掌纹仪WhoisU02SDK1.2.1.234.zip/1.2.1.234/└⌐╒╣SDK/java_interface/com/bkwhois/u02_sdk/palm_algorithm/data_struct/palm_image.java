/**
 *
 */
package com.bkwhois.u02_sdk.palm_algorithm.data_struct;

import java.lang.Exception;

/**
 * @author 陶海军
 *
 */
/// 手掌灰度图像
public class palm_image {

    public palm_image(final int width, final int height, final byte[] data) throws Exception {
        if (width <= 0 || height <= 0) {
            throw new Exception("palm_image Constructor error");
        }

        _width = width;
        _height = height;

        if (data != null) {
            if (data.length != width * height) {
                _data = new byte[_width * _height];
            } else {
                _data = data;
            }
        } else {
            _data = new byte[_width * _height];
        }
    }
	
	public byte[] getData() {
    	return _data;
    }

    protected int _width;
    protected int _height;
    protected byte[] _data;
}
