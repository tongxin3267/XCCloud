#include "maindlg.h"
#include <iostream>
#include <QPushButton>
#include "enroll_dlg.h"
#include "include/qt_ui_lib_interface.h"
#include <QHBoxLayout>
#include <QVBoxLayout>

maindlg::maindlg(QWidget *parent)
    : QDialog(parent)
{
    init_ui();

    if(!m_pPalmLoginView->start("", "./")) {
        std::cout << "特征采集控件启动失败" << std::endl;
    }
    else {
        connect(m_pPalmLoginView, SIGNAL(signal_feature_got(std::string,std::string)), this, SLOT(on_feature_got(std::string,std::string)));
        connect(_pEnrollBtn, SIGNAL(pressed()), this, SLOT(on_enroll()));
    }
}

maindlg::~maindlg()
{
    if(m_pPalmLoginView) {
        m_pPalmLoginView->stop();
    }
}

void maindlg::init_ui()
{
    m_pPalmLoginView = create_feature_collect_view(0);
    m_pPalmLoginView->setFixedSize(640, 480);

    QHBoxLayout *pviewLayout = new QHBoxLayout();
    pviewLayout->addWidget(m_pPalmLoginView);

    QHBoxLayout *btn_layout = new QHBoxLayout();
    _pEnrollBtn = new QPushButton(QString::fromUtf8("注册手掌特征"));
    btn_layout->addStretch(2);
    btn_layout->addWidget(_pEnrollBtn);
    btn_layout->addStretch(2);

    QVBoxLayout *mainLayout = new QVBoxLayout();

    mainLayout->addLayout(pviewLayout);
    mainLayout->addStretch(1);
    mainLayout->addLayout(btn_layout);

    setLayout(mainLayout);
    setFixedSize(800, 600);

    setWindowTitle(QString::fromUtf8("手掌特征采集"));
}

void maindlg::on_feature_got(const std::string fea, const std::string md5)
{
    std::cout << "FEATURE:" << fea << std::endl;
    std::cout << "MD5:" << md5 << std::endl;
}

void maindlg::on_enroll()
{
    m_pPalmLoginView->stop();

    enroll_dlg dlg;

    dlg.start();
    dlg.exec();

    if(dlg._is_succeed) {
        std::cout << "FEATURE:" << dlg._fea << std::endl;
        std::cout << "MD5:" << dlg._md5 << std::endl;
    }

    m_pPalmLoginView->start("", "./");
}
