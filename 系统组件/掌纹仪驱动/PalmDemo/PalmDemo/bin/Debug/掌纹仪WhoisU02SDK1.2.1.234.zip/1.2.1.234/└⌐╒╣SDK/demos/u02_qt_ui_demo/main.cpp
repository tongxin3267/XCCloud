#include "maindlg.h"
#include <QApplication>
#include <QMetaType>
#include <string>

using namespace std;

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);

    qRegisterMetaType<string>("std::string");

    maindlg fea_collect_dlg;
    fea_collect_dlg.exec();

//    app.exec();

    return 0;
}
