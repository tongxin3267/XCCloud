#ifndef MAINDLG_H
#define MAINDLG_H

#include <QDialog>
#include "include/i_feature_collect_view.h"

class maindlg : public QDialog
{
    Q_OBJECT
    
public:
    explicit maindlg(QWidget *parent = 0);
    virtual ~maindlg();

private slots:
    void on_feature_got(const std::string fea, const std::string md5);

private slots:
    void on_enroll();

protected:
//    virtual void accept() { close(); }
//    virtual void reject() { close(); }

private:
    void init_ui();

private:
    //识别画面界面
    i_feature_collect_view*            m_pPalmLoginView;
    QPushButton*                _pEnrollBtn;
};

#endif // MAINDLG_H
