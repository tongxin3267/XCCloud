#include "enroll_dlg.h"
#include <iostream>
#include "include/qt_ui_lib_interface.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include "include/data_structs.h"

enroll_dlg::enroll_dlg(QWidget *parent)
    : QDialog(parent)
    , _is_succeed(false)
{
    init_ui();

    connect(_penroll_view, SIGNAL(signal_enroll_finish(uint,std::string,std::string)), this, SLOT(on_enroll_finish(uint,std::string,std::string)));
    connect(_pclose_btn, SIGNAL(pressed()), this, SLOT(close()));
}

enroll_dlg::~enroll_dlg()
{
    if(_penroll_view) {
        _penroll_view->stop();
    }
}

void enroll_dlg::start()
{
    if( !_penroll_view->start("", "./", 0) ) {
        std::cout << "注册控件启动失败." << std::endl;
    }
}

void enroll_dlg::init_ui()
{
    _penroll_view = create_feature_enroll_view(0);
    _penroll_view->setFixedSize(640, 480);

    QHBoxLayout *pviewLayout = new QHBoxLayout();
    pviewLayout->addWidget(_penroll_view);

    QHBoxLayout *btn_layout = new QHBoxLayout();
    _pclose_btn = new QPushButton(QString::fromUtf8("关闭"));
    btn_layout->addStretch(2);
    btn_layout->addWidget(_pclose_btn);
    btn_layout->addStretch(2);

    QVBoxLayout *mainLayout = new QVBoxLayout();

    mainLayout->addLayout(pviewLayout);
    mainLayout->addStretch(1);
    mainLayout->addLayout(btn_layout);

    setLayout(mainLayout);
    setFixedSize(800, 600);

    setWindowTitle(QString::fromUtf8("手掌注册"));
}

void enroll_dlg::on_enroll_finish(unsigned int msg, std::string fea_str, std::string fea_md5)
{
    if(msg == action_enroll_suc) {
        _is_succeed = true;
        _fea = fea_str;
        _md5 = fea_md5;
    }

    close();
}

void enroll_dlg::closeEvent(QCloseEvent *e)
{
    _penroll_view->stop();
}
