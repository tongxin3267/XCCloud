import java.io.*;
import whois_ws_match_stub.*;

/// 本程序用于说whois服务器WebServices比对调用
public class whois_ws_match_client {
	public static void main(String[] args) {
		String feature_captured = null;
		String feature_md5 = null;
		FileReader rcg_fr = null;
		BufferedReader rcg_bw = null;
		

		MatchServiceImplService match_ws_impl = new MatchServiceImplService();
		MatchService match_ws = match_ws_impl.getMatchServiceImplPort();
		
		// 1:N模式
		try {
			rcg_fr = new FileReader("rcg_feature.txt");
			rcg_bw = new BufferedReader(rcg_fr);

			// 读取特征(实际上是模拟网络传输过来的特征)，每一个特征相当于一对图像（可见光、红外光），下面的例子就是模拟图像序列与所有特征的比对
			// 一旦发现某副图像比对成功，后续图像也就无需再比了。
			while( (feature_captured = rcg_bw.readLine()) != null && (feature_md5 = rcg_bw.readLine()) != null) {
				long start = System.currentTimeMillis();
				System.out.print("web service request start\n");
				
				String rcg_name = match_ws.match1Vn(feature_captured, feature_md5); 

				// 比对库中所有的特征
				if(!rcg_name.isEmpty()) {
					System.out.println("we got an user, the user is:" + rcg_name);
				}
				
				System.out.print("Web service request returned, ");
				System.out.print("Total time:");
				System.out.print(System.currentTimeMillis() - start);
				System.out.print(" ms\n");
			}

			rcg_bw.close();
			rcg_fr.close();
		} catch (Exception e) {
			System.out.println("error occured");
			return;
		}
	}
}