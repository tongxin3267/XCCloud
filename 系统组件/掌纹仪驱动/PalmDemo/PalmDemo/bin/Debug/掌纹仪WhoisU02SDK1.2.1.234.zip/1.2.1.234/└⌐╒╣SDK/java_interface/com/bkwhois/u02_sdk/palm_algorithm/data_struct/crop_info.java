/**
 * 
 */
package com.bkwhois.u02_sdk.palm_algorithm.data_struct;

/**
 * @author 陶海军
 *
 */
/// 裁剪中心块信息
public class crop_info {
    public crop_info(card_point key[], card_point roi[]) {
        cptKey = key;
        cptROI = roi;
    }

    /// 两个关键点，顺序为(左,右)
    public card_point[] cptKey;
    /// 中心块的四个点，顺序为(左上,右上,左下,右下)
    public card_point[] cptROI;
}
