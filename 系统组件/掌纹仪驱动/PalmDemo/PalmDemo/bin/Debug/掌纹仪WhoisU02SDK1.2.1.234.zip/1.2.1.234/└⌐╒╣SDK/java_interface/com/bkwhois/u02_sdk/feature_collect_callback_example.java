import com.bkwhois.u02_sdk.palm_algorithm.data_struct.frame_info;
import com.bkwhois.u02_sdk.palm_workflow.i_workflow_callback;

public class feature_collect_callback_example implements i_workflow_callback {
    /// 在workflow启动前的初始化调用
    /// @param image_cx 图像宽度
    /// @param image_cy 图像高度
    /// @return 初始化成功 or 失败
    public boolean init(final int image_cx, final int image_cy) {
        System.out.print("feature_collect_callback_example::init called, image_cx:");
        System.out.print(image_cx);
        System.out.print("\timage_cy:");
        System.out.println(image_cy);

        return true;
    }

    /// 新图像到来，通知客户程序更新
    /// @param display_info 图像信息，当注册流程收不到图像时，会发送0给本接口
    /// @note 当前图像是同步传输，因此本函数不返回时，注册流程不会继续，请保证本函数尽快返回，以防影响注册流程阻塞。
    public void attach(frame_info display_info, String fea_str, String md5) {
        System.out.print("feature_collect_callback_example::attach called, frame_info is ");
        System.out.println(display_info);

        if (display_info != null && fea_str != null && md5 != null) {
            System.out.println(fea_str);
            System.out.println(md5);

            System.out.print("crop result is:");
            System.out.println(display_info._crop_rslt);
        }
    }

    /// 给客户端发送通知，例如识别、注册等动作，具体动作依据注册流程决定 @see workflow_actions
    /// @param Msg 通知的类型
    /// @param wParam 通知参数1
    /// @param lparam 通知参数2
    /// @return 通知的处理结果
    public int notify(final int Action, final int wParam, final int lParam, String tmpl_str, String md5) {
        System.out.print("feature_collect_callback_example::notify called, Action is ");
        System.out.print(Action);
        System.out.print("\t wParam:");
        System.out.print(wParam);
        System.out.print("\tlParam:");
        System.out.println(lParam);

        return 1;
    }
}
