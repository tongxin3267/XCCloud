#ifndef I_FEATURE_COLLECT_VIEW_H
#define I_FEATURE_COLLECT_VIEW_H
#include <QWidget>

class i_feature_collect_view : public QWidget
{
    Q_OBJECT
public:
    i_feature_collect_view(QWidget *parent):QWidget(parent) {}

signals:
    ///手掌进入信号，通知调用程序
    void signal_palm_in();
    ///手掌离开信号，通知调用程序
    void signal_palm_out();
    ///对外的信号，即通知调用者获取到特征了
    void signal_feature_got(const std::string &fea_str, const std::string &fea_md5);

public:
    virtual bool start(const std::string &device_id, const std::string &data_path) = 0;
    virtual bool stop() = 0;
    virtual void suspend() = 0;
    virtual void resume() = 0;
    virtual bool is_stopped() = 0;
    virtual bool is_suspended() = 0;
};

#endif // I_FEATURE_COLLECT_VIEW_H

