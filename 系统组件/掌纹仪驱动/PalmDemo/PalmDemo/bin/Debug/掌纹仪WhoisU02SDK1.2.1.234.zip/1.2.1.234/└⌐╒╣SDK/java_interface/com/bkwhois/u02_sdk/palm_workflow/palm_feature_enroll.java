/**
 *
 */
package com.bkwhois.u02_sdk.palm_workflow;

/**
 * @author 陶海军
 *
 */
/// 手掌特征注册jni接口定义
public class palm_feature_enroll {
    /// 启动手掌特征注册流程
    /// @param device_id 要启动的注册设备的设备id
    /// @param data_path 应用程序数据目录，用于存储畸变矫正文件
    /// @param p_callback 接收注册事件的回调接口
    /// @return 流程启动成功否	
    public native boolean start(final String device_id, final String data_path, i_workflow_callback i_callback);

    /// 关闭手掌特征注册流程
    public native boolean stop();
	
	/// 判断流程是否关闭
	public native boolean isstopped();
	
	/// 设置注册模式, 0->25模板，1->5模板
	public native boolean setenrolltype(final int type);

    static {
        System.loadLibrary("palm_feature_enroll_jni");
    }
}
