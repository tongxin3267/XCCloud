/**
 * 
 */
package com.bkwhois.u02_sdk.palm_algorithm.data_struct;

/**
 * @author 陶海军
 *
 */
/// 直角坐标系点定义
public class card_point {
    public card_point(final int x, final int y) { _x = x; _y = y; }
    public card_point(final card_point src) { _x = src._x; _y = src._y; }
    public int get_x() { return _x; }
    public int get_y() { return _y; }
    public void set_x(final int x) { _x = x; }
    public void set_y(final int y) { _y = y; }
    public void set(final card_point src) {
        set_x(src._x);
        set_y(src._y);
    }
    public void offset(final card_point ptOffset) { _x += ptOffset._x; _y += ptOffset._y; }
    public void scale(final int fScale) { _x *= fScale; _y *= fScale; }
    public void revert() { _x = -_x; _y = -_y; }
    public boolean is_equal(final card_point pt) {
        if(_x == pt._x && _y == pt._y)
            return true;

        return false;
    } 

    private int _x;
    private int _y;
}
