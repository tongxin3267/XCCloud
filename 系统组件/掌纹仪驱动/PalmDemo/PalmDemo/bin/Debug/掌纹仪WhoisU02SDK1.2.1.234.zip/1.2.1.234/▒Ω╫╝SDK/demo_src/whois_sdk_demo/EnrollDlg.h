#pragma once
#include "whois_enroll_ocxctrl1.h"

// CEnrollDlg dialog

class CEnrollDlg : public CDialog
{
	DECLARE_DYNAMIC(CEnrollDlg)

public:
	CEnrollDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CEnrollDlg();

// Dialog Data
	enum { IDD = IDD_ENROLL_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	// ע��ؼ�
	CWhois_enroll_ocxctrl1 m_enroll_ctrl;
	virtual BOOL OnInitDialog();
	DECLARE_EVENTSINK_MAP()
	void EnrollFinish(LPCTSTR feature_str, LPCTSTR md5);
	void EnrollFail();

public:
	CString m_user_name;
	string  _feature_str;
	string  _md5;
	afx_msg void OnBnClickedStart();
	BOOL _small_templ;
	BOOL _bone_stage;
	int _language_id;
	afx_msg void OnClose();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
