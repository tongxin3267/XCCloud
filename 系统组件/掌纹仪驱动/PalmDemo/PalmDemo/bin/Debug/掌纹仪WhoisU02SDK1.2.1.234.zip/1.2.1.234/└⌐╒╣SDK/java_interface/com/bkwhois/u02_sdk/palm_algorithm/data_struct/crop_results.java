/**
 * 
 */
package com.bkwhois.u02_sdk.palm_algorithm.data_struct;

/**
 * @author 陶海军
 *
 */
/// 一帧（可见/红外）裁剪中心块信息
public class crop_results {
    public crop_results(crop_results_each rsltir, crop_results_each rsltvl, double ratio, double angle, card_point centerpt) {
        rsltNIR = rsltir;
        rsltVL  = rsltvl;
        cptCenter = centerpt;

        fWhiteRatio = ratio; fAngle = angle;
    }

    /// 近红外图像裁减信息
    public crop_results_each rsltNIR;
    /// 可见光图像裁减信息
    public crop_results_each rsltVL;
    /// 手掌图像二值化后，白色区域占中间方框的面积百分比（畸变的近红外图像）
    public double fWhiteRatio;
    /// 根据关键点计算的旋转角度（畸变的近红外图像）
    public double fAngle;
    /// 中心点位置
    public card_point cptCenter;
}
