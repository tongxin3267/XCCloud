#include "stdafx.h"

#include "simple_user_manager.h"
#include <fstream>
#include <sstream>
#include <boost/filesystem.hpp>
#include <iostream>
#include <boost/xpressive/xpressive_dynamic.hpp>

typedef boost::filesystem::directory_iterator rd_iterator;

using namespace boost::filesystem;
typedef vector<string> vstring;

string create_folder(string folderpath)
{
	boost::filesystem::create_directory(folderpath);
	return folderpath;
}

void _parse_files_or_folders(vstring& results, const string &root_folder, const string &filter, bool bFolder)
{
	results.clear();

	boost::filesystem::path root_path(root_folder);

	// �������һ��Ŀ¼��ֱ�ӷ���
	if(!boost::filesystem::exists(root_path) ||  !boost::filesystem::is_directory(root_path))
		return;

	//�Ѿ������ ��MFC������DEBUG_NEW����, ֻҪ���������ͱ���,ԭ���� by vcfly 2012.5.2
	boost::xpressive::sregex rex = boost::xpressive::sregex::compile(filter.c_str(), boost::xpressive::regex_constants::icase);

	rd_iterator end;
	for(rd_iterator ite(root_path); ite != end; ++ite)
	{
		boost::filesystem::path tmp = ite->path();
		boost::xpressive::smatch what;

		if((bFolder == is_directory(tmp)) && regex_match(tmp.filename().string(), what, rex)) {
			results.push_back(tmp.string());
		}
	}
}

void parse_folders(vstring& results, const string &rootfolder, const string &filter)	{	_parse_files_or_folders(results, rootfolder, filter, TRUE);	}

mbstate_t in_cvt_state;
mbstate_t out_cvt_state;
const std::wstring s2ws(const std::string& s)
{
	std::locale sys_loc("");
	const char* src_str = s.c_str();
	const size_t BUFFER_SIZE = s.size() + 1;
	wchar_t *intern_buffer = new wchar_t[BUFFER_SIZE];
	wmemset(intern_buffer, 0, BUFFER_SIZE);
	const char* extern_from = src_str;
	const char* extern_from_end = extern_from + s.size();
	const char* extern_from_next = 0;
	wchar_t* intern_to = intern_buffer;
	wchar_t* intern_to_end = intern_to + BUFFER_SIZE;
	wchar_t* intern_to_next = 0;
	typedef std::codecvt<wchar_t, char, mbstate_t> CodecvtFacet;

	CodecvtFacet::result cvt_rst =
		std::use_facet<CodecvtFacet>(sys_loc).in(in_cvt_state, extern_from, extern_from_end, extern_from_next, intern_to, intern_to_end, intern_to_next);

	if (cvt_rst != CodecvtFacet::ok) {
		switch(cvt_rst) {
		case CodecvtFacet::partial:
			std::cerr << "partial";
			break;

		case CodecvtFacet::error:
			std::cerr << "error";
			break;

		case CodecvtFacet::noconv:
			std::cerr << "noconv";
			break;

		default:
			std::cerr << "unknown";
		}

		std::cerr  << ", please check in_cvt_state."<< std::endl;
	}

	std::wstring result = intern_buffer;

	delete []intern_buffer;

	return result;
}

const std::string ws2s(const std::wstring& ws)
{
	std::locale sys_loc("");
	const wchar_t* src_wstr = ws.c_str();
	const size_t MAX_UNICODE_BYTES = 4;
	const size_t BUFFER_SIZE = ws.size() * MAX_UNICODE_BYTES + 1;

	char *extern_buffer = new char[BUFFER_SIZE];
	memset(extern_buffer, 0, BUFFER_SIZE);
	const wchar_t* intern_from = src_wstr;
	const wchar_t* intern_from_end = intern_from + ws.size();
	const wchar_t* intern_from_next = 0;
	char* extern_to = extern_buffer;
	char* extern_to_end = extern_to + BUFFER_SIZE;
	char* extern_to_next = 0;

	typedef std::codecvt<wchar_t, char, mbstate_t> CodecvtFacet;

	CodecvtFacet::result cvt_rst =
		std::use_facet<CodecvtFacet>(sys_loc).out(out_cvt_state, intern_from, intern_from_end, intern_from_next, extern_to, extern_to_end, extern_to_next);

	if (cvt_rst != CodecvtFacet::ok) {
		switch(cvt_rst) {
		case CodecvtFacet::partial:
			std::cerr << "partial";
			break;

		case CodecvtFacet::error:
			std::cerr << "error";
			break;

		case CodecvtFacet::noconv:
			std::cerr << "noconv";
			break;

		default:
			std::cerr << "unknown";
		}

		std::cerr << ", please check out_cvt_state."<< std::endl;
	}

	std::string result = extern_buffer;

	delete []extern_buffer;

	return result;
}


//����û��б���������
void simple_user_manager::clear()
{
	for(std::map<std::string, int>::const_iterator ite = _users_map.begin(); ite != _users_map.end(); ++ite)
		del_user(ite->first);

	_users_map.clear();
	_feature_map.clear();
}

bool simple_user_manager::get_usr_name_and_id(const std::string &usr_file_name, std::string &usr_name, int &id)
{
	boost::property_tree::ptree usr_info;

	std::string tmp_path = usr_file_name;

	try {
		boost::property_tree::ini_parser::read_ini(tmp_path, usr_info);
	}catch(boost::property_tree::ini_parser::ini_parser_error&) {
		return false;
	}

	usr_name = usr_info.get<std::string>("default.caption");

	size_t split_index = usr_file_name.find_last_of("\\");

	std::string dir_path = usr_file_name.substr(0, split_index);

	if(dir_path == "") return false;

	std::string id_str = dir_path.substr(usr_file_name.find_last_of("_") + 1, usr_file_name.length() - usr_file_name.find_last_of("_"));

	id = boost::lexical_cast<int>(id_str);

	return true;
}

//װ�������û�
bool simple_user_manager::load_user_lib(const std::string &path)
{
	clear();

	std::vector<std::string> usr_dirs;

	create_folder(path);

	parse_folders(usr_dirs, path, ".*");

	if(usr_dirs.size() >= 0) _store_path = path;

	if(!get_last_user_id(path)) return false;

	for(unsigned int i = 0; i<usr_dirs.size(); ++i) {
		std::string usr_name;
		int id = -1;
		std::string usr_info_file_name = usr_dirs[i] + USER_INFO_FILE_NAME;

		if(!get_usr_name_and_id(usr_info_file_name, usr_name, id))
			continue;

		_feature_map[id] = get_fea_string(id);

		std::string feature_file_name = usr_dirs[i] + FEATURE_FILE_NAME;
		_users_map[usr_name] = id;
	}


	return usr_dirs.size() >= 0;
}

//ɾ���û�
bool simple_user_manager::del_user(const std::string &user_name)
{
	std::map<std::string, int>::iterator ite = _users_map.find(user_name);

	if(ite == _users_map.end()) return false;

	std::map<int, std::string>::iterator fea_ite = _feature_map.find(ite->second);

	std::stringstream stream;
	stream<<_store_path<<"\\ui_"<<ite->second;
	boost::filesystem::remove_all(stream.str());

	_users_map.erase(ite);

	if(fea_ite != _feature_map.end())
		_feature_map.erase(fea_ite);

	return true;
}

//�����û�
bool simple_user_manager::add_user(const std::string &user_name, const std::string &feature_str, const std::string &md5)
{
	//����û��Ѿ����ڣ�����
	if(_store_path == _T("") || _users_map.find(user_name) != _users_map.end()) return false;

	std::stringstream stream;
	stream<<_store_path<<"\\ui_"<<_last_id;
	create_directory(stream.str());

	std::string feature_file_path = stream.str()+ FEATURE_FILE_NAME;

	ofstream ofs(feature_file_path.c_str());
	ofs << feature_str;

	boost::property_tree::ptree usr_info;
	usr_info.put("default.caption", user_name);

	boost::property_tree::ini_parser::write_ini(stream.str() + USER_INFO_FILE_NAME, usr_info);

	_users_map[user_name] = _last_id;
	_feature_map[_last_id] = feature_str;

	_last_id ++;

	return true;
}

bool simple_user_manager::get_last_user_id(const std::string &path)
{
	boost::property_tree::ptree id_tree;

	try {
		boost::property_tree::ini_parser::read_ini(path + FEATURE_LIB_INFO_FILE_NAME, id_tree);
	}
	catch(boost::property_tree::ini_parser::ini_parser_error) {
		return false;
	}

	std::string id_str = id_tree.get<std::string>("default.lastid");

	if(id_str == "") return false;

	_last_id = boost::lexical_cast<unsigned int>(id_str);

	return true;
}

// ����base64���룬rc4����
string simple_user_manager::get_fea_string(const int id) const
{
	std::stringstream stream;
	stream<<_store_path<<"\\ui_"<<id<<FEATURE_FILE_NAME;

	string total_path = stream.str();

	ifstream ifm(total_path.c_str());

	string ret_value;

	ifm>>ret_value;

	return ret_value;
}

// ��ȡ�û��б�
vector<int> simple_user_manager::get_id_list() const
{
	vector<int> ret_vec;
	for(std::map<string, int>::const_iterator ite = _users_map.begin(); ite != _users_map.end(); ++ite)
		ret_vec.push_back(ite->second);

	return ret_vec;
}

string simple_user_manager::get_feature(const int id) const
{
	map<int, std::string>::const_iterator ite = _feature_map.find(id);

	if(ite == _feature_map.end()) return "";

	return ite->second;
}