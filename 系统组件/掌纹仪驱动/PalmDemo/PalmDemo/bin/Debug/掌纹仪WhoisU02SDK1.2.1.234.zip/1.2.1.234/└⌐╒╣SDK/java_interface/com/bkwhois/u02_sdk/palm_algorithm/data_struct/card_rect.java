/**
 *
 */
package com.bkwhois.u02_sdk.palm_algorithm.data_struct;

/**
 * @author 陶海军
 *
 */
/// 直角坐标系上的矩形
public class card_rect {

    public card_rect(final card_point top_left, final card_point bottom_right) {
        _top_left = top_left;
        _bottom_right = bottom_right;
    }

    public card_point _top_left;
    public card_point _bottom_right;

    public int get_width() {
        return Math.abs(_bottom_right.get_x() - _top_left.get_x());
    }

    public int get_height() {
        return Math.abs(_bottom_right.get_y() - _top_left.get_y());
    }
}
