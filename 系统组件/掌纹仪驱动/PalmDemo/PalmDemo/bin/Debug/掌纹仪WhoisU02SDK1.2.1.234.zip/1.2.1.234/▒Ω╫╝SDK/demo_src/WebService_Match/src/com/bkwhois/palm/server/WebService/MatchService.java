package com.bkwhois.palm.server.WebService;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

@WebService
@SOAPBinding(style = Style.RPC)
public interface MatchService {
	@WebMethod String match_1vn(final String fea_str, final String md5);
	//@WebMethod boolean match_1v1(final String key_id, final String fea_str, final String md5);
}