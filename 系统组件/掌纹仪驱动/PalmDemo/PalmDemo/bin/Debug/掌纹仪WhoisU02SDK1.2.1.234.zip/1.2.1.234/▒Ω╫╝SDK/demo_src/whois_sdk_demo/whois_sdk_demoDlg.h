// whois_sdk_demoDlg.h : ͷ�ļ�
//

#pragma once
#include "whois_feature_exctrl1.h"
#include "simple_user_manager.h"
#include "afxcmn.h"


// Cwhois_sdk_demoDlg �Ի���
class Cwhois_sdk_demoDlg : public CDialog
{
// ����
public:
	Cwhois_sdk_demoDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_WHOIS_SDK_DEMO_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBnClickedEnrollButton();
	afx_msg void OnBnClickedDeleteUserButton();
	afx_msg LRESULT on_user_logon(WPARAM uid, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

public:
	DECLARE_EVENTSINK_MAP()
	void on_ocx_feature_got(LPCTSTR feature_str, LPCTSTR md5);
	void refresh_user_list();

private:
	// �����ɼ��ؼ�
	CWhois_feature_exctrl1 m_feature_extract_ctrl;
	simple_user_manager _usr_lib;
	// �û��б���
	CListCtrl m_user_list_ctrl;
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};