package com.bkwhois.palm.server.WebService;

import com.bkwhois.palm.server.*;
import javax.jws.WebService;
import java.io.*;

@WebService(endpointInterface = "com.bkwhois.palm.server.WebService.MatchService")
public class MatchServiceImpl implements MatchService {
	static final int DEFAULT_PARTITION = 0;
	static final int LIB_SIZE = 30000;
	static final int MATCH_NORMAL = 1;
	
	//构造函数负责生成对应的<用户, 特征模板>对，调用libweb_feature_match.so的jni接口初始化该动态库
	public MatchServiceImpl() {
		_matcher = new feature_match();
		
		_matcher.create_rcg_partition(DEFAULT_PARTITION);
		_matcher.set_match_policy(DEFAULT_PARTITION, MATCH_NORMAL);
		
		try {
			// 从文件中读取注册特征
			FileReader enrolled_fr = new FileReader("/tmp/enroll_feature.txt");
			BufferedReader enrolled_bw=new BufferedReader(enrolled_fr);
			
			String enrolled_feature = null;
			
			if ( (/*user_name = */enrolled_bw.readLine()) != null && (enrolled_feature = enrolled_bw.readLine()) != null && (/*enrolled_md5 = */enrolled_bw.readLine()) != null) {
				// 生成LIB_SIZE个相同的特征
				for(int i = 0; i<LIB_SIZE; ++i) {
					_matcher.match_1vN_push_template(DEFAULT_PARTITION, Integer.toString(i+100), enrolled_feature);
				}
			}

			enrolled_bw.close();
			enrolled_fr.close();
		} catch (Exception e) {
			return;
		}
	};
	
	protected void finalize() {
		_matcher.delete_partition(DEFAULT_PARTITION);
	}
	
	//调用libweb_feature_match.so的Java_whois_palm_server_feature_1match_whois_1match_11vN_1jni函数实现1：N比对
	public String match_1vn(final String fea_str, final String md5) {
		String u_name = null;
		boolean bsuc = _matcher.match_1vN(DEFAULT_PARTITION, fea_str, md5);
		
		if(bsuc) {
			u_name = _matcher.match_1vN_get_identify_user_name(DEFAULT_PARTITION);
		}
		else
			u_name = new String("");
		
		_matcher.match_1vN_reset_identify_process(DEFAULT_PARTITION);

		return u_name;
	};
	
	//比对动态库实例
	private feature_match _matcher;
}
