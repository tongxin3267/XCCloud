/**
 *
 */
package com.bkwhois.u02_sdk.palm_workflow;

/**
 * @author root
 *
 */
/// 掌纹特征采集动态库接口
public class palm_feature_collect {
    /// 启动掌纹特征采集流程
    /// @param device_id 要启动的采集设备的设备id
    /// @param data_path 应用程序数据目录，用于存储畸变矫正文件
    /// @param p_callback 接收采集事件的回调接口
    /// @return 流程启动成功否
    public native boolean start(final String device_id, final String data_path, i_workflow_callback p_callback);

    /// 关闭掌纹特征采集流程
    public native boolean stop();

    /// 暂停掌纹特征采集流程
    public native void suspend();

    /// 恢复掌纹特征采集流程
    public native void resume();
	
    /// 判断采集是否停止
    public native boolean isstopped();

    /// 判断采集是否挂起
    public native boolean issuspended();

    static {
        System.loadLibrary("palm_feature_collect_jni");
    }
}
