/**
 *
 */
package com.bkwhois.u02_sdk.palm_algorithm.data_struct;

import java.lang.Exception;

/**
 * @author 陶海军
 *
 */
/// 掌纹掌脉帧信息，包括两幅图像
public class image_pair {

    public image_pair(final int width, final int height, final byte[] li_image, final byte[] ir_image) {
        try {
            _li_image = new palm_image(width, height, li_image);
            _ir_image = new palm_image(width, height, ir_image);
        } catch (Exception e) {
            System.out.print(e);
        }
    }

    /// 可见光图像
    public palm_image _li_image;
    /// 红外光图像
    public palm_image _ir_image;
};
