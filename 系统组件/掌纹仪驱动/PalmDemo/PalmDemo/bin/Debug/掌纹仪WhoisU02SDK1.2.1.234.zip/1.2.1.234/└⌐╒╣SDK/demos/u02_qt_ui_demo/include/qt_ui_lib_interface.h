#ifndef UI_LIB_INTERFACE_H
#define UI_LIB_INTERFACE_H
#include "i_feature_enroll_view.h"
#include "i_feature_collect_view.h"

///创建特征采集窗体控件实例，调用者负责释放该实例
i_feature_collect_view* create_feature_collect_view(QWidget *parent);

///创建注册窗体控件实例，调用者负责释放该实例
i_feature_enroll_view* create_feature_enroll_view(QWidget *parent);

#endif // UI_LIB_INTERFACE_H

