#ifndef I_FEATURE_ENROLL_VIEW_H
#define I_FEATURE_ENROLL_VIEW_H
#include <QWidget>

class i_feature_enroll_view : public QWidget
{
    Q_OBJECT
public:
    i_feature_enroll_view(QWidget *parent):QWidget(parent) {}

signals:
    ///手掌进入信号，通知调用程序
    void signal_palm_in();
    ///手掌离开信号，通知调用程序
    void signal_palm_out();
    ///注册结束信号，通知调用程序
    ///@param msg, 注册结束状态，为@see action_enroll_suc 或者 @see action_enroll_fail
    ///@param fea_str, 若状态为action_enroll_suc，本参数返回特征字符串
    ///@param fea_md5, 若状态为action_enroll_suc, 本参数返回特征字符串的md5校验值
    void signal_enroll_finish(unsigned int msg, std::string fea_str, std::string fea_md5);

public:
    virtual bool start(const std::string &device_id, const std::string &data_path, const int enroll_type) = 0;
    virtual bool stop() = 0;
    virtual bool is_stopped() = 0;
    //virtual void show_finish_enroll(bool success = true) = 0;
};

#endif // I_FEATURE_ENROLL_VIEW_H

