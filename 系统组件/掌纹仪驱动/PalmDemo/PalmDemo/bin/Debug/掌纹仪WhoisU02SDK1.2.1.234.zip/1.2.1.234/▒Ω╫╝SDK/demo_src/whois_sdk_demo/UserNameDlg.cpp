// UserNameDlg.cpp : implementation file
//

#include "stdafx.h"
#include "whois_sdk_demo.h"
#include "UserNameDlg.h"


// CUserNameDlg dialog

IMPLEMENT_DYNAMIC(CUserNameDlg, CDialog)

CUserNameDlg::CUserNameDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUserNameDlg::IDD, pParent)
	, m_username(_T(""))
{

}

CUserNameDlg::~CUserNameDlg()
{
}

void CUserNameDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_USER_NAME_EDIT, m_username);
}


BEGIN_MESSAGE_MAP(CUserNameDlg, CDialog)
	ON_BN_CLICKED(IDOK, &CUserNameDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// CUserNameDlg message handlers

void CUserNameDlg::OnBnClickedOk()
{
	UpdateData();

	if(m_username == _T("")) {
		AfxMessageBox(_T("�û�������Ϊ��"));
		return;
	}

	OnOK();
}

BOOL CUserNameDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetDlgItem(IDC_USER_NAME_EDIT)->SetFocus();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CUserNameDlg::OnCancel()
{
	UpdateData();

	if(m_username == _T("")) {
		AfxMessageBox(_T("�û�������Ϊ��"));
		return;
	}

	CDialog::OnCancel();
}