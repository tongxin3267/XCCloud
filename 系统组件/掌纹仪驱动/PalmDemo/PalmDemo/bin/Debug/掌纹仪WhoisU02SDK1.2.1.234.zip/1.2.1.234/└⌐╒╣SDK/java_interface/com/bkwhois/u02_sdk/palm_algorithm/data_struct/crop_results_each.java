/**
 * 
 */
package com.bkwhois.u02_sdk.palm_algorithm.data_struct;

/**
 * @author 陶海军
 *
 */
/// 单个摄像头的裁剪中心块信息
public class crop_results_each {
    public crop_results_each(crop_info normal, crop_info distort) {
            infoNormal = normal;
            infoDistort = distort;
    }
    /// 校正图像的裁剪信息
    public crop_info infoNormal;
    /// 畸变图像的裁剪信息
    public crop_info infoDistort;
}
