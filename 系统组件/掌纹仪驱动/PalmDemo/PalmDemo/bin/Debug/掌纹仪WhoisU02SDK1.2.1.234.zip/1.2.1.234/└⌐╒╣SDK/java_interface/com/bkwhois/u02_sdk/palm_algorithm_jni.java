import com.bkwhois.u02_sdk.palm_workflow.*;

public class palm_algorithm_jni {

    /**
     * @param args 特征采集代码测试
     */
    public static void main(String[] args) {
        feature_collect_callback_example callback_inst = new feature_collect_callback_example();
        palm_feature_collect collect_inst = new palm_feature_collect();

        if (!collect_inst.start("", ".", callback_inst)) {
            System.out.println("collect instance start failed");
            return;
        }

        try {
            Thread.sleep(5 * 1000);
        } catch (InterruptedException e) {
            return;
        }

        collect_inst.suspend();

        try {
            Thread.sleep(3 * 1000);
        } catch (InterruptedException e) {
            return;
        }

        collect_inst.resume();

        try {
            Thread.sleep(5 * 1000);
        } catch (InterruptedException e) {
            return;
        }

        collect_inst.stop();
    }

    /**
     * @param args 特征注册代码测试
     */
   /*public static void main(String[] args) {
        feature_enroll_callback_example callback_inst = new feature_enroll_callback_example();
        palm_feature_enroll enroll_inst = new palm_feature_enroll();

        if (!enroll_inst.start("", ".", callback_inst)) {
            System.out.println("enroll instance start failed;");
        }

        try {
            Thread.sleep(60 * 1000);
            enroll_inst.stop();
            System.out.println("enroll instance stoped;");

        } catch (InterruptedException e) {
            return;
        }

        try {
            Thread.sleep(1000);
            if (!enroll_inst.start("", ".", callback_inst)) {
                System.out.println("enroll instance start failed;");
            } else {
                System.out.println("enroll instance restarted;");
            }
        } catch (InterruptedException e) {
            return;
        }

        try {
            Thread.sleep(60 * 1000);
            enroll_inst.stop();
            System.out.println("system exit;");
        } catch (InterruptedException e) {
            return;
        }
    }*/
}
