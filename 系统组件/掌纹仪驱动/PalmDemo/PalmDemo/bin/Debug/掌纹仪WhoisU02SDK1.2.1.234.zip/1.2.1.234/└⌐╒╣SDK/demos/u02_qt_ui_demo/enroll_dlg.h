#ifndef ENROLL_DLG_H
#define ENROLL_DLG_H

#include <QDialog>
#include "include/i_feature_enroll_view.h"

class enroll_dlg : public QDialog
{
    Q_OBJECT
    
public:
    explicit enroll_dlg(QWidget *parent = 0);
    ~enroll_dlg();

private:
    void init_ui();

private slots:
    void on_enroll_finish(unsigned int msg, std::string fea_str, std::string fea_md5);

protected:
    virtual void closeEvent(QCloseEvent *e);

public:
    void start();

private:
    i_feature_enroll_view *_penroll_view;
    QPushButton*           _pclose_btn;

public:
    bool                 _is_succeed;
    std::string          _fea;
    std::string          _md5;
};

#endif // ENROLL_DLG_H
